//
//  TemperatureViewController.swift
//  WeatherViewer
//
//  Created by Nivedhitha Parthasarathy on 06/08/20.
//  Copyright © 2020 Nivedhitha Parthasarathy. All rights reserved.
//

import UIKit
import Alamofire
import Charts

class TemperatureViewController: UIViewController, ChartViewDelegate{

    @IBOutlet weak var tempChartView: LineChartView!
    
    var arrTemp = [Daily]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tempChartView.delegate = self
        tempChartView.backgroundColor = .white
        tempChartView.gridBackgroundColor = #colorLiteral(red: 0.9568627477, green: 0.6588235497, blue: 0.5450980663, alpha: 1)
        tempChartView.leftAxis.gridColor = .clear
        tempChartView.rightAxis.gridColor = .clear
        tempChartView.rightAxis.enabled = false
        tempChartView.xAxis.gridColor = .clear
        tempChartView.xAxis.granularity = 1
        tempChartView.xAxis.wordWrapEnabled = true
        tempChartView.xAxis.labelPosition = .bottom
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        getWeatherForecast{(responseObject, error) in
        if(error == nil && responseObject!.count > 0){
            DispatchQueue.main.async {
                self.updateChartData()
            }
        }
    }
    }
    
    func getWeatherForecast(completionHandler: @escaping ([Daily]?, Error?) -> ()) {
        let urlRequest = "https://api.openweathermap.org/data/2.5/onecall?lat=11.016844&lon=76.955833&units=metric&appid=f4ea2a97d814e1090e6290ec1483ff73"
        
        Alamofire.request(urlRequest).validate()
            .responseString {
                response in
                print(response)
                
                
                switch response.result {
                case .success:
                    do{
                        let forecast = try JSONDecoder().decode(Weather_forecast.self, from:response.data!)
                        self.arrTemp = forecast.daily!
                        
                        completionHandler(self.arrTemp, nil)
                    }
                    catch {
                        completionHandler(nil, error)
                    }
                case .failure(let error):
                    
                    completionHandler(nil, error)
                    
                }
        }
    }
    
    func updateChartData() {
//        if self.shouldHideData {
//            tempChartView.data = nil
//            return
//        }
        var lineChartEntry1 = [ChartDataEntry]()
        var lineChartEntry2 = [ChartDataEntry]()
        var arrDate = [String]()
        for i in 0..<arrTemp.count {
            if let timeResult = (arrTemp[i].dt) {
                let date = NSDate(timeIntervalSince1970: TimeInterval(timeResult))
                let dateFormatter = DateFormatter()
                dateFormatter.dateFormat = "MM/dd"
                let localDate = dateFormatter.string(from: date as Date)
                arrDate.append(localDate)
                let value1 = ChartDataEntry(x:Double(i), y:(arrTemp[i].temp?.min)!)
                lineChartEntry1.append(value1)
                let value2 = ChartDataEntry(x:Double(i), y:(arrTemp[i].temp?.max)!)
                lineChartEntry2.append(value2)
            }
        }
        
        let set1 = LineChartDataSet(values: lineChartEntry1, label: "Min Temperature Difference")
        set1.axisDependency = .left
        set1.setColor(#colorLiteral(red: 0.2392156869, green: 0.6745098233, blue: 0.9686274529, alpha: 1))
        set1.drawCirclesEnabled = false
        set1.lineWidth = 2
        set1.circleRadius = 3
        set1.fillAlpha = 1
        set1.drawFilledEnabled = true
        set1.fillColor = #colorLiteral(red: 0.2392156869, green: 0.6745098233, blue: 0.9686274529, alpha: 1)
        set1.highlightColor = UIColor(red: 244/255, green: 117/255, blue: 117/255, alpha: 1)
        set1.drawCircleHoleEnabled = false
        set1.fillFormatter = DefaultFillFormatter { _,_  -> CGFloat in
            return CGFloat(self.tempChartView.leftAxis.axisMinimum)
        }
        
        let set2 = LineChartDataSet(values: lineChartEntry2, label: "Max Temperature")
        set2.axisDependency = .left
        set2.setColor(#colorLiteral(red: 0.9254902005, green: 0.2352941185, blue: 0.1019607857, alpha: 1))
        set2.drawCirclesEnabled = false
        set2.lineWidth = 2
        set2.circleRadius = 3
        set2.fillAlpha = 1
        set2.drawFilledEnabled = true
        set2.fillColor = #colorLiteral(red: 0.9411764741, green: 0.4980392158, blue: 0.3529411852, alpha: 0.595703125)
        set2.highlightColor = UIColor(red: 244/255, green: 117/255, blue: 117/255, alpha: 1)
        set2.drawCircleHoleEnabled = false
        set2.fillFormatter = DefaultFillFormatter { _,_  -> CGFloat in
            return CGFloat(self.tempChartView.leftAxis.axisMinimum)
        }

        tempChartView.xAxis.valueFormatter = IndexAxisValueFormatter(values: arrDate)
        let data = LineChartData(dataSets: [set1, set2])
        
        tempChartView.data = data
        tempChartView.notifyDataSetChanged()
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
