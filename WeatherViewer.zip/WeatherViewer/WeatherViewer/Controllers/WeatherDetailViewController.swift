//
//  WeatherDetailViewController.swift
//  WeatherViewer
//
//  Created by Nivedhitha Parthasarathy on 06/08/20.
//  Copyright © 2020 Nivedhitha Parthasarathy. All rights reserved.
//

import UIKit
import Alamofire
import CoreLocation
import UserNotifications

var lat: String!
var lon: String!

class WeatherDetailViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, UICollectionViewDelegate, UICollectionViewDataSource, UNUserNotificationCenterDelegate {
    
    @IBOutlet weak var lblWeather: UILabel!
    @IBOutlet weak var lblLocation: UILabel!
    @IBOutlet weak var lblTemp: UILabel!
    @IBOutlet weak var imgWeather: UIImageView!
    @IBOutlet weak var lblHumidity: UILabel!
    @IBOutlet weak var lblDate: UILabel!
    @IBOutlet weak var lblWeekDay: UILabel!
    @IBOutlet weak var lblTempFelt: UILabel!
    @IBOutlet weak var lblUVIndex: UILabel!
    @IBOutlet weak var lblVisibility: UILabel!
    @IBOutlet weak var lblAirPressure: UILabel!
    @IBOutlet weak var lblCloudiness: UILabel!
    @IBOutlet weak var weatherColView: UICollectionView!
    @IBOutlet weak var dailyForecastTV: UITableView!
    
    var locationManager = CLLocationManager()
    var arrWeatherDetails = [Hourly]()
    var arrForecastDetails = [Daily]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        locationManager.requestWhenInUseAuthorization()
        var currentLoc: CLLocation!
        if(CLLocationManager.authorizationStatus() == .authorizedWhenInUse ||
            CLLocationManager.authorizationStatus() == .authorizedAlways) {
            currentLoc = locationManager.location
            if currentLoc != nil{
                lat = String(currentLoc.coordinate.latitude)
                lon = String(currentLoc.coordinate.longitude)
                
            }
            else{
                print("Location not found")
            }
        }
        let debitOverdraftNotifCategory = UNNotificationCategory(identifier: "Weather Viewer", actions: [], intentIdentifiers: [], options: [])
        // #1.2 - Register the notification type.
        UNUserNotificationCenter.current().setNotificationCategories([debitOverdraftNotifCategory])
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        if lat != nil || lon != nil {
        getWeatherForecast{(responseObject, error) in
            if(error == nil && responseObject != nil){
                DispatchQueue.main.async {
                    let location: CLLocation = CLLocation(latitude: (responseObject?.lat!)!, longitude: (responseObject?.lon!)!)//Convert lat & lng in to CLLocation
                        
                        let geocoder = CLGeocoder()
                        geocoder.reverseGeocodeLocation(location) { (placemarksArray, error) in
                            print(placemarksArray!)
                            if (error) == nil {
                                if placemarksArray!.count > 0 {
                                    let placemark = placemarksArray?[0]
                                    self.lblLocation.text = placemark?.locality
                                }
                            }
                            
                        }
                    let iconStr = (responseObject?.current?.weather![0].icon)!
                        self.imgWeather.load(url: URL(string:"http://openweathermap.org/img/wn/\(iconStr)@2x.png")!)
                    self.lblTemp.text = "\(Int((responseObject?.current?.temp)!))°C"
                    self.lblWeather.text = responseObject?.current?.weather![0].description
                    self.lblTempFelt.text = "\((responseObject?.current?.feels_like)!)°C"
                    self.lblUVIndex.text = "\((responseObject?.current?.uvi)!)"
                    self.lblVisibility.text = "\((responseObject?.current?.visibility)!)"
                    self.lblHumidity.text = "\((responseObject?.current?.humidity)!)%"
                    self.lblAirPressure.text = "\((responseObject?.current?.pressure)!)hPa"
                    self.lblCloudiness.text = "\((responseObject?.current?.clouds)!)%"
                    if let timeResult = (responseObject?.current?.dt) {
                            let date = NSDate(timeIntervalSince1970: TimeInterval(timeResult))
                            let dateFormatter = DateFormatter()
                            dateFormatter.dateFormat = "MM/dd"
                            let localDate = dateFormatter.string(from: date as Date)
                            self.lblDate.text = localDate
                            let dateFormatter1 = DateFormatter()
                            dateFormatter1.dateFormat = "EEEE"
                            let localDate1 = dateFormatter1.string(from: date as Date)
                            self.lblWeekDay.text = localDate1
                        }
                        
                        self.weatherColView.reloadData()
                        self.dailyForecastTV.reloadData()
                    
                    let content = UNMutableNotificationContent()
                    content.categoryIdentifier = "Weather Viewer"
                    //adding title, subtitle, body and badge
                    content.title = "Weather"
                    content.subtitle = self.lblLocation.text!
                    content.body = "Weather condition in \(self.lblLocation.text!) is \(( responseObject?.current?.weather![0].main)!)"
                    content.badge = 1
                    content.sound = UNNotificationSound.default
                    //getting the notification trigger
                    //it will be called after 0.5 seconds
                    let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 300, repeats: false)
                    let uuidString = UUID().uuidString
                    //getting the notification request
                    let request = UNNotificationRequest(identifier: uuidString, content: content, trigger: trigger)
                    
                    UNUserNotificationCenter.current().delegate = self
                    
                    //adding the notification to notification center
                    UNUserNotificationCenter.current().add(request, withCompletionHandler: nil)
                    
                }
            }
        }
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    
    func getWeatherForecast(completionHandler: @escaping (Weather_forecast?, Error?) -> ()){
        let urlRequest = "https://api.openweathermap.org/data/2.5/onecall?lat=\(lat)&lon=\(lon)&units=metric&appid=f4ea2a97d814e1090e6290ec1483ff73"
        
        Alamofire.request(urlRequest).validate()
            .responseString {
                response in
                print(response)
                
                
                switch response.result {
                case .success:
                    do{
                        let forecast = try JSONDecoder().decode(Weather_forecast.self, from:response.data!)
                        self.arrWeatherDetails = forecast.hourly!
                        self.arrForecastDetails = forecast.daily!
                        completionHandler(forecast, nil)
                    }
                    catch {
                        completionHandler(nil, error)
                    }
                                    case .failure(let error):
                    print("Weather Forecast: \(error)")
                    completionHandler(nil, error)
                    
                    
                }
        }

        
    }
    
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        
        //displaying the ios local notification when app is in foreground
        completionHandler([.alert, .badge, .sound])
    }
    
    func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse, withCompletionHandler completionHandler: @escaping () -> Void) {
        
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arrWeatherDetails.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "WeatherCell", for: indexPath) as! WeatherCell
        cell.lblWeather.text = arrWeatherDetails[indexPath.item].weather![0].description
        cell.lblTemp.text = "\(Int(arrWeatherDetails[indexPath.item].temp!))°C"
        if let timeResult = (arrWeatherDetails[indexPath.item].dt) {
            let date = NSDate(timeIntervalSince1970: TimeInterval(timeResult))
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "h:mm a"
            let localDate = dateFormatter.string(from: date as Date)
            cell.lblTime.text = localDate
        }
        DispatchQueue.main.async {
            let iconStr = (self.arrWeatherDetails[indexPath.item].weather![0].icon)!
            cell.imgWeather.load(url: URL(string:"http://openweathermap.org/img/wn/\(iconStr)@2x.png")!)
        }
        return cell
    }
    

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrForecastDetails.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ForecastCell") as! ForecastCell
        cell.lblWeather.text = arrForecastDetails[indexPath.row].weather![0].description
        cell.lblTemp.text = "\(Int((arrForecastDetails[indexPath.row].temp?.min)!))/\(Int((arrForecastDetails[indexPath.row].temp?.max)!))°C"
        if let timeResult = (arrForecastDetails[indexPath.item].dt) {
            let date = NSDate(timeIntervalSince1970: TimeInterval(timeResult))
            let dateFormatter = DateFormatter()
                dateFormatter.dateFormat = "MMM d E"
                let localDate = dateFormatter.string(from: date as Date)
                cell.lblDate.text = localDate
        }
        DispatchQueue.main.async {
            let iconStr = (self.arrForecastDetails[indexPath.item].weather![0].icon)!
            cell.imgWeather.load(url: URL(string:"http://openweathermap.org/img/wn/\(iconStr)@2x.png")!)
        }
        return cell
    }
    
    @IBAction func cancel_LocalNotification(_ sender: Any) {
        let alert = UIAlertController(title: "Are you sure you want to cancel the notifications?", message: "", preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "Yes", style: UIAlertAction.Style.default, handler: {action in
            UNUserNotificationCenter.current().removeAllPendingNotificationRequests()
        }))
        alert.addAction(UIAlertAction(title: "No", style: UIAlertAction.Style.cancel, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

extension UIImageView {
    func load(url: URL) {
        DispatchQueue.global().async { [weak self] in
            if let data = try? Data(contentsOf: url) {
                if let image = UIImage(data: data) {
                    DispatchQueue.main.async {
                        self?.image = image
                    }
                }
            }
        }
    }
}
