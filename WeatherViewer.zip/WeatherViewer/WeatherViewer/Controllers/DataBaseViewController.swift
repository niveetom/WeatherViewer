//
//  DataBaseViewController.swift
//  WeatherViewer
//
//  Created by Nivedhitha Parthasarathy on 09/08/20.
//  Copyright © 2020 Nivedhitha Parthasarathy. All rights reserved.
//

import UIKit

class DataBaseViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var dataBaseTV: UITableView!
    
    var db:DBHelper = DBHelper()
    var weatherViewer = [WeatherViewer]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
//        weatherViewer = db.read()
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        DispatchQueue.main.async {
            self.weatherViewer = self.db.read()
            self.dataBaseTV.reloadData()
        }
        
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return weatherViewer.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "DataBaseCell") as! DataBaseCell
        cell.lblName.text = weatherViewer[indexPath.row].name
        cell.lblLocation.text = weatherViewer[indexPath.row].location
        cell.lblLatitude.text = "\(weatherViewer[indexPath.row].latitude)"
        cell.lblLongitude.text = "\(weatherViewer[indexPath.row].longitude)"
        return cell
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
