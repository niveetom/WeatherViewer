//
//  JSONCodable.swift
//  WeatherViewer
//
//  Created by Nivedhitha Parthasarathy on 06/08/20.
//  Copyright © 2020 Nivedhitha Parthasarathy. All rights reserved.
//


import Foundation
struct Weather_forecast : Codable {
    let lat : Double?
    let lon : Double?
    let timezone : String?
    let timezone_offset : Int?
    let current : Current?
    let hourly : [Hourly]?
    let daily : [Daily]?
    
    enum CodingKeys: String, CodingKey {
        
        case lat = "lat"
        case lon = "lon"
        case timezone = "timezone"
        case timezone_offset = "timezone_offset"
        case current = "current"
        case hourly = "hourly"
        case daily = "daily"
    }
    
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        lat = try values.decodeIfPresent(Double.self, forKey: .lat)
        lon = try values.decodeIfPresent(Double.self, forKey: .lon)
        timezone = try values.decodeIfPresent(String.self, forKey: .timezone)
        timezone_offset = try values.decodeIfPresent(Int.self, forKey: .timezone_offset)
        current = try values.decodeIfPresent(Current.self, forKey: .current)
        hourly = try values.decodeIfPresent([Hourly].self, forKey: .hourly)
        daily = try values.decodeIfPresent([Daily].self, forKey: .daily)
    }
    
}

struct Current : Codable {
    let dt : Int?
    let sunrise : Int?
    let sunset : Int?
    let temp : Double?
    let feels_like : Double?
    let pressure : Int?
    let humidity : Int?
    let dew_point : Double?
    let uvi : Double?
    let clouds : Int?
    let visibility : Int?
    let wind_speed : Double?
    let wind_deg : Int?
    let weather : [Weather]?
    
    enum CodingKeys: String, CodingKey {
        
        case dt = "dt"
        case sunrise = "sunrise"
        case sunset = "sunset"
        case temp = "temp"
        case feels_like = "feels_like"
        case pressure = "pressure"
        case humidity = "humidity"
        case dew_point = "dew_point"
        case uvi = "uvi"
        case clouds = "clouds"
        case visibility = "visibility"
        case wind_speed = "wind_speed"
        case wind_deg = "wind_deg"
        case weather = "weather"
    }
    
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        dt = try values.decodeIfPresent(Int.self, forKey: .dt)
        sunrise = try values.decodeIfPresent(Int.self, forKey: .sunrise)
        sunset = try values.decodeIfPresent(Int.self, forKey: .sunset)
        temp = try values.decodeIfPresent(Double.self, forKey: .temp)
        feels_like = try values.decodeIfPresent(Double.self, forKey: .feels_like)
        pressure = try values.decodeIfPresent(Int.self, forKey: .pressure)
        humidity = try values.decodeIfPresent(Int.self, forKey: .humidity)
        dew_point = try values.decodeIfPresent(Double.self, forKey: .dew_point)
        uvi = try values.decodeIfPresent(Double.self, forKey: .uvi)
        clouds = try values.decodeIfPresent(Int.self, forKey: .clouds)
        visibility = try values.decodeIfPresent(Int.self, forKey: .visibility)
        wind_speed = try values.decodeIfPresent(Double.self, forKey: .wind_speed)
        wind_deg = try values.decodeIfPresent(Int.self, forKey: .wind_deg)
        weather = try values.decodeIfPresent([Weather].self, forKey: .weather)
    }
    
}

struct Hourly : Codable {
    let dt : Int?
    let temp : Double?
    let feels_like : Double?
    let pressure : Int?
    let humidity : Int?
    let dew_point : Double?
    let clouds : Int?
    let visibility : Int?
    let wind_speed : Double?
    let wind_deg : Int?
    let weather : [Weather]?
    let pop : Double?
    let rain : Rain?
    
    enum CodingKeys: String, CodingKey {
        
        case dt = "dt"
        case temp = "temp"
        case feels_like = "feels_like"
        case pressure = "pressure"
        case humidity = "humidity"
        case dew_point = "dew_point"
        case clouds = "clouds"
        case visibility = "visibility"
        case wind_speed = "wind_speed"
        case wind_deg = "wind_deg"
        case weather = "weather"
        case pop = "pop"
        case rain = "rain"
    }
    
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        dt = try values.decodeIfPresent(Int.self, forKey: .dt)
        temp = try values.decodeIfPresent(Double.self, forKey: .temp)
        feels_like = try values.decodeIfPresent(Double.self, forKey: .feels_like)
        pressure = try values.decodeIfPresent(Int.self, forKey: .pressure)
        humidity = try values.decodeIfPresent(Int.self, forKey: .humidity)
        dew_point = try values.decodeIfPresent(Double.self, forKey: .dew_point)
        clouds = try values.decodeIfPresent(Int.self, forKey: .clouds)
        visibility = try values.decodeIfPresent(Int.self, forKey: .visibility)
        wind_speed = try values.decodeIfPresent(Double.self, forKey: .wind_speed)
        wind_deg = try values.decodeIfPresent(Int.self, forKey: .wind_deg)
        weather = try values.decodeIfPresent([Weather].self, forKey: .weather)
        pop = try values.decodeIfPresent(Double.self, forKey: .pop)
        rain = try values.decodeIfPresent(Rain.self, forKey: .rain)
    }
    
}

struct Daily : Codable {
    let dt : Int?
    let sunrise : Int?
    let sunset : Int?
    let temp : Temp?
    let feels_like : Feels_like?
    let pressure : Int?
    let humidity : Int?
    let dew_point : Double?
    let wind_speed : Double?
    let wind_deg : Int?
    let weather : [Weather]?
    let clouds : Int?
    let pop : Double?
    let rain : Double?
    let uvi : Double?
    
    enum CodingKeys: String, CodingKey {
        
        case dt = "dt"
        case sunrise = "sunrise"
        case sunset = "sunset"
        case temp = "temp"
        case feels_like = "feels_like"
        case pressure = "pressure"
        case humidity = "humidity"
        case dew_point = "dew_point"
        case wind_speed = "wind_speed"
        case wind_deg = "wind_deg"
        case weather = "weather"
        case clouds = "clouds"
        case pop = "pop"
        case rain = "rain"
        case uvi = "uvi"
    }
    
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        dt = try values.decodeIfPresent(Int.self, forKey: .dt)
        sunrise = try values.decodeIfPresent(Int.self, forKey: .sunrise)
        sunset = try values.decodeIfPresent(Int.self, forKey: .sunset)
        temp = try values.decodeIfPresent(Temp.self, forKey: .temp)
        feels_like = try values.decodeIfPresent(Feels_like.self, forKey: .feels_like)
        pressure = try values.decodeIfPresent(Int.self, forKey: .pressure)
        humidity = try values.decodeIfPresent(Int.self, forKey: .humidity)
        dew_point = try values.decodeIfPresent(Double.self, forKey: .dew_point)
        wind_speed = try values.decodeIfPresent(Double.self, forKey: .wind_speed)
        wind_deg = try values.decodeIfPresent(Int.self, forKey: .wind_deg)
        weather = try values.decodeIfPresent([Weather].self, forKey: .weather)
        clouds = try values.decodeIfPresent(Int.self, forKey: .clouds)
        pop = try values.decodeIfPresent(Double.self, forKey: .pop)
        rain = try values.decodeIfPresent(Double.self, forKey: .rain)
        uvi = try values.decodeIfPresent(Double.self, forKey: .uvi)
    }
    
}

struct Weather : Codable {
    let id : Int?
    let main : String?
    let description : String?
    let icon : String?
    
    enum CodingKeys: String, CodingKey {
        
        case id = "id"
        case main = "main"
        case description = "description"
        case icon = "icon"
    }
    
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        id = try values.decodeIfPresent(Int.self, forKey: .id)
        main = try values.decodeIfPresent(String.self, forKey: .main)
        description = try values.decodeIfPresent(String.self, forKey: .description)
        icon = try values.decodeIfPresent(String.self, forKey: .icon)
    }
    
}

struct Rain : Codable {
    let oneh : Double?
    
    enum CodingKeys: String, CodingKey {
        
        case oneh = "1h"
    }
    
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        oneh = try values.decodeIfPresent(Double.self, forKey: .oneh)
    }
    
}

struct Temp : Codable {
    let day : Double?
    let min : Double?
    let max : Double?
    let night : Double?
    let eve : Double?
    let morn : Double?
    
    enum CodingKeys: String, CodingKey {
        
        case day = "day"
        case min = "min"
        case max = "max"
        case night = "night"
        case eve = "eve"
        case morn = "morn"
    }
    
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        day = try values.decodeIfPresent(Double.self, forKey: .day)
        min = try values.decodeIfPresent(Double.self, forKey: .min)
        max = try values.decodeIfPresent(Double.self, forKey: .max)
        night = try values.decodeIfPresent(Double.self, forKey: .night)
        eve = try values.decodeIfPresent(Double.self, forKey: .eve)
        morn = try values.decodeIfPresent(Double.self, forKey: .morn)
    }
    
}

struct Feels_like : Codable {
    let day : Double?
    let night : Double?
    let eve : Double?
    let morn : Double?
    
    enum CodingKeys: String, CodingKey {
        
        case day = "day"
        case night = "night"
        case eve = "eve"
        case morn = "morn"
    }
    
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        day = try values.decodeIfPresent(Double.self, forKey: .day)
        night = try values.decodeIfPresent(Double.self, forKey: .night)
        eve = try values.decodeIfPresent(Double.self, forKey: .eve)
        morn = try values.decodeIfPresent(Double.self, forKey: .morn)
    }
    
}
